<?php 

if(isset($_POST['submit'])){ 
session_start();
include "admin/config.php";
$username   =$_POST['username'];
$password =md5($_POST['pass']);
$query=  mysqli_query($koneksi, "SELECT * FROM login where username='$username' and password='$password'");
$jumlah=  mysqli_num_rows($query);
if($jumlah>0){
    $r=  mysqli_fetch_array($query);
    $_SESSION['status_login']='sudah_login';
    $_SESSION['nama']=$r['username'];
    header("location:admin/index.php");
}
else{ 
  echo "<SCRIPT type='text/javascript'>
        alert('Maaf kamu kurang hokkie untuk memasuki surga admin :v');
        window.location.replace('index.php');
        </SCRIPT>";
}
}
  ?>


<!DOCTYPE html>

<html lang="en">
    <head>
      <meta charset="utf-8">
      <title>Envylook - Fashion Stylish Home Industri</title>
      <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">

      <!-- Favicon ================== -->
      <!-- Standard -->
      <link rel="shortcut icon" href="assets/img/favicon-144.png">
      <!-- Retina iPad Touch Icon-->
      <link rel="apple-touch-icon" sizes="144x144" href="assets/img/favicon-144.png">
      <!-- Retina iPhone Touch Icon-->
      <link rel="apple-touch-icon" sizes="114x114" href="assets/img/favicon-114.png">
      <!-- Standard iPad Touch Icon-->
      <link rel="apple-touch-icon" sizes="72x72" href="assets/img/favicon-72.png">
      <!-- Standard iPhone Touch Icon-->
      <link rel="apple-touch-icon" sizes="57x57" href="assets/img/favicon-57.png">

      <!--  Resources style ================== -->
      <link href="assets/css/advanced-Portage.css" rel="stylesheet" type="text/css" media="all"/>
    </head>
    <body>

    <!-- BEGIN # MODAL LOGIN -->
<div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
      <div class="modal-dialog">
      <div class="modal-content" style="margin-top: 120px;">
        <div class="modal-header" align="center">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span class="ion-close-round" aria-hidden="true"></span>
          </button>
          <img class="img-circle" id="img_logo" src="assets/img/logo.png">
          <h2 align="center" style="color: #fff; margin-bottom: 0px; padding-bottom: 0px;">ENVY<strong>LOOK</strong> </h2>
        </div>
                
                <!-- Begin # DIV Form -->
                <div id="div-forms">
                
                    <!-- Begin # Login Form -->
                    <form id="login-form" action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
                    <div class="modal-body">
                <div id="div-login-msg">
                                <div id="icon-login-msg" class="icon ion-information-circled"> </div>
                                <span id="text-login-msg" style="font-size: 12px;">Isikan username dan password kamu.</span>
                            </div>
                <input id="login_username" name="username" maxlength="40" class="form-control" type="text" placeholder="Username" required>
                <input id="login_password" name="pass" maxlength="50" class="form-control" type="password" placeholder="Password" required>
                         <!--   <div class="checkbox">
                                <label>
                                    <input type="checkbox"> Remember me
                                </label>
                            </div> -->
                  </div>
                <div class="modal-footer">
                            <div>
                                <button type="submit" name="submit" class="button-light pull-right">Login</button>
                            </div>
     
                </div>
                    </form>
                    <!-- End # Login Form -->
                </div>
                <!-- End # DIV Form -->
                
      </div>
    </div>
  </div>
    <!-- END # MODAL LOGIN -->
      <section class="animsition">



        <div id="leftSide" class="slideshow">
          <!--<div class="background-img-holder gradient">
            <img src="assets/img/coffee-apple-iphone-desk.jpg" alt="This is my work">
          </div>-->

          <div id="home" class="gradient">
            <!-- Your logo -->
  			    <img src="assets/img/logo.png" alt="" class="main-logo" />

            <div class="h-content">
              <div class="heading text-white">
                <h1>The look you want to steal</h1>
                <h4>Be envied with your very own style. Asian fashion clothing for women & man fashion style</h4> <br/>
                <a href="#" class="button-light" role="button" data-toggle="modal" data-target="#login-modal">Masuk Login</a>


              </div>
            </div>

            <ul class="social_icons">
              <li><a href="#"><i class="icon ion-social-facebook"></i></a></li>
              <li><a href="#"><i class="icon ion-social-twitter"></i></a></li>
              <li><a href="#"><i class="icon ion-social-instagram"></i></a></li>
              <li><a href="#"><i class="icon ion-social-youtube"></i></a></li>       
            </ul>
          </div>
        </div>

        <div id="rightSide">

            <div class="appContainer">
              <div class="row">
                <div class="ipad-app col-sm-12 col-xs-12">
                  <img src="assets/img/women.png" alt="This is my work" class="img-responsive"/>
                </div>

              </div>
            </div>
      
            <!-- Hidden slider Lol :D 
            <div id="slider" class="flexslider">
              <ul class="slides">
                <li>
                  <img src="assets/img/apple-iphone-technology-white.jpg" />
                </li>
                <li>
                  <img src="assets/img/coffee-apple-iphone-desk.jpg" />
                </li>
              </ul>
            </div> -->
            <!--
            <div id="subscribe">
              <h2>Stay tunned we're coming this year</h2>
              <div class="mb100" id="clock" data-date="2016/08/02 12:00:00"></div>

              <form
              id="subscribe-form"
              action="http://coderare.us12.list-manage.com/subscribe/post-json?u=112a29375b248b89f47be54b7&amp;id=e46717ab68"
              method="get">
                <input type="email" name="EMAIL" class="input-email" value="" placeholder="Fill Your Email Address Here...">
                <input type="submit" name="subscribe" class="submit button-light input-submit" value="Subscribe">
                <div id="subscribe-result"></div>
              </form>
            </div> -->

            

            <div class="about">
              <h2>Our Philosophy</h2>
              <p>
                We Believe that customer satisfaction and quality comes first.
                That's why we spend so much time listening to our customer and designing our merchandise with them in mind.
                If YOU look and feel good and are happy, then we're happy. In fact,
                we challenge ourselves on a daily basis not only to produce quality clothing,
                but also to design the most fashionable,trend setting apparel that makes our customer feel special.
              </p>

              <p>
                We create stylish dresses and tailoring to beautifully made footwear,perfect for playtime and special occasions.From t-shirts and tops to denim and shoes, shop this season’s collection of cool clothing and footwear for contrumers.
              </p>

              <div class="service row">

                <div class="col-sm-4 col-xs-4">
                  <div class="feature">
                    <span class="upper_icon" aria-hidden="true">
                      <i class="ion-heart"></i>
                    </span>
                    <span class="lower_icon">
                      <i class="ion-heart"></i>
                      <h6>Dibuat dengan Cinta</h6>
                    </span>
                  </div>
                </div>

                <div class="col-sm-4 col-xs-4">
                  <div class="feature">
                    <span class="upper_icon" aria-hidden="true">
                      <i class="ion-woman"></i>
                    </span>
                    <span class="lower_icon">
                      <i class="ion-woman"></i>
                      <h6>Pakain Wanita Termodis</h6>
                    </span>
                  </div>
                </div>

                <div class="col-sm-4 col-xs-4">
                  <div class="feature">
                    <span class="upper_icon">
                      <i class="ion-man"></i>
                    </span>
                    <span class="lower_icon">
                      <i class="ion-man"></i>
                      <h6>Pakaian Pria Terkini</h6>
                    </span>
                  </div>
                </div>

                <div class="col-sm-4 col-xs-4">
                  <div class="feature">
                    <span class="upper_icon">
                      <i class="ion-earth"></i>
                    </span>
                    <span class="lower_icon">
                      <i class="ion-earth"></i>
                      <h6>Penjualan Mancanegara</h6>
                    </span>
                  </div>
                </div>

                <div class="col-sm-4 col-xs-4">
                  <div class="feature">
                    <span class="upper_icon" aria-hidden="true">
                      <i class="ion-ribbon-b"></i>
                    </span>
                    <span class="lower_icon">
                      <i class="ion-ribbon-b"></i>
                      <h6>Kualitas Bahan Terbaik</h6>
                    </span>
                  </div>
                </div>

                <div class="col-sm-4 col-xs-4">
                  <div class="feature">
                    <span class="upper_icon">
                      <i class="ion-cash"></i>
                    </span>
                    <span class="lower_icon">
                      <i class="ion-cash"></i>
                      <h6>Harga Yang Bersahabat</h6>
                    </span>
                  </div>
                </div>

              </div>
            </div>

            <div class="portfolio">
              <ul class="gallery">
                <div class="grid-sizer col-sm-4 col-xs-6"></div>

                <li class="item col-sm-4 col-xs-6">
                  <a href="assets/img/app1.jpg"  title="Style Fashion Women one">
                    <figure>
                      <!-- Your picture -->
                      <img src="assets/img/app1.jpg" alt="This is my work" class="img-responsive" />
                    <!-- Picture's description below this one -->
                    <figcaption class="caption">
                      <div class="photo-details">
                        <h4>Style Fashion Women one</h4>
                        <span>By EnvyLook</span>
                      </div>
                    </figcaption>
                    </figure>
                  </a>
                </li>

                <li class="item col-sm-4 col-xs-6">
                  <a href="assets/img/app2.jpg" title="Style Fashion Women Two">
                    <figure>
                        <!-- Your picture -->
                        <img src="assets/img/app2.jpg" alt="This is my work" class="img-responsive" />
                      <!-- Picture's description below this one -->
                      <figcaption class="caption">
                        <div class="photo-details">
                          <h4>Style Fashion Women Two</h4>
                        <span>By EnvyLook</span>
                        </div>
                      </figcaption>
                    </figure>
                  </a>
                </li>

                <li class="item col-sm-4 col-xs-6">
                  <a href="assets/img/app3.jpg" title="Style Fashion Women Three">
                    <figure>
                        <!-- Your picture -->
                        <img src="assets/img/app3.jpg" alt="This is my work" class="img-responsive" />
                      <!-- Picture's description below this one -->
                      <figcaption class="caption">
                        <div class="photo-details">
                          <h4>Style Fashion Women Three</h4>
                        <span>By EnvyLook</span>
                        </div>
                      </figcaption>
                    </figure>
                  </a>
                </li>

                <li class="item col-sm-4 col-xs-6">
                  <a href="assets/img/app4.jpg" title="Style Fashion Man One">
                    <figure>
                        <!-- Your picture -->
                        <img src="assets/img/app4.jpg" alt="This is my work" class="img-responsive" />
                      <!-- Picture's description below this one -->
                      <figcaption class="caption">
                        <div class="photo-details">
                          <h4>Style Fashion Man One</h4>
                        <span>By EnvyLook</span>
                        </div>
                      </figcaption>
                    </figure>
                  </a>
                </li>

                <li class="item col-sm-4 col-xs-6">
                  <a href="assets/img/app5.jpg" title="Style Fashion Man Two">
                    <figure>
                        <!-- Your picture -->
                        <img src="assets/img/app5.jpg" alt="This is my work" class="img-responsive" />
                      <!-- Picture's description below this one -->
                      <figcaption class="caption">
                        <div class="photo-details">
                          <h4>Style Fashion Man Two</h4>
                        <span>By EnvyLook</span>
                        </div>
                      </figcaption>
                    </figure>
                  </a>
                </li>

                <li class="item col-sm-4 col-xs-6">
                  <a href="assets/img/app6.jpg" title="Style Fashion Man Three">
                    <figure>
                        <!-- Your picture -->
                        <img src="assets/img/app6.jpg" alt="This is my work" class="img img-responsive" />
                      <!-- Picture's description below this one -->
                      <figcaption class="caption">
                        <div class="photo-details">
                          <h4>Style Fashion Man Three</h4>
                        <span>By EnvyLook</span>
                        </div>
                      </figcaption>
                    </figure>
                  </a>
                </li>
              </ul>
            </div>

            <footer>
              <p class="uppercase">© Copyright 2016 - dengan cinta <i class="ion-heart"></i></p>
              <div class="drag">
                <i class="up ion-arrow-up-c"></i>
              </div>
            </footer>

          </div>
      </section>

      <script src="assets/js/jquery-1.11.3.min.js"></script>
      <script src="assets/js/bootstrap.min.js"></script>
      <script src="assets/js/animsition.min.js"></script>
      <script src="assets/js/jquery.magnific-popup.min.js"></script>
      <script src="assets/js/masonry.pkgd.min.js"></script>
      <script src="assets/js/imagesloaded.pkgd.min.js"></script>
      <script src="assets/js/jquery.flexslider-min.js"></script>
      <script src="assets/js/photoswipe.min.js"></script>
      <script src="assets/js/photoswipe-ui-default.min.js"></script>
      <script src="assets/js/script.js"></script>
       <script src="assets/js/vegas.min.js"></script>
       <script type="text/javascript">
        $(function() {
            $('.slideshow').vegas({
              delay:4000,
              timer: false,
                slides: [
                    { src: 'assets/img/bg-4.jpg' },
                    { src: 'assets/img/bg-1.jpg' },
                    { src: 'assets/img/bg-3.jpg' },
                    { src: 'assets/img/bg-6.jpg' }
                ]

            });
        });
      </script>

      <script type="text/javascript">

$(function() {
    
    var $formLogin = $('#login-form');
    var $divForms = $('#div-forms');
    var $modalAnimateTime = 300;
    var $msgAnimateTime = 150;
    var $msgShowTime = 2000;

    $("form").submit(function () {
        switch(this.id) {
            case "login-form":
                var $lg_username=$('#login_username').val();
                var $lg_password=$('#login_password').val();
                if ($lg_username == "ERROR") {
                    msgChange($('#div-login-msg'), $('#icon-login-msg'), $('#text-login-msg'), "error", "glyphicon-remove", "Login error");
                } else {
                    msgChange($('#div-login-msg'), $('#icon-login-msg'), $('#text-login-msg'), "success", "glyphicon-ok", "Login OK");
                }
                return false;
                break;
            default:
                return false;
        }
        return false;
    });
    
    $('#login_register_btn').click( function () { modalAnimate($formLogin, $formRegister) });
   
    
    function modalAnimate ($oldForm, $newForm) {
        var $oldH = $oldForm.height();
        var $newH = $newForm.height();
        $divForms.css("height",$oldH);
        $oldForm.fadeToggle($modalAnimateTime, function(){
            $divForms.animate({height: $newH}, $modalAnimateTime, function(){
                $newForm.fadeToggle($modalAnimateTime);
            });
        });
    }

});
      </script>

  </body>
</html>

