        <!-- awal:main -->
        <div class="container">
            <div id="main">
                <!-- awal:breadcrumb -->
                <ol class="breadcrumb">
                    <li><a href="#">Beranda</a></li>
                    <li class="active">Error 404</li>
                </ol>
                <!-- akhir:breadcrumb -->

                <div class="row" id="home-content">
                   <div class="errorpage" align="center">
			            <i class="fa fa-frown-o fa-4x"></i>
			            <h1>404</h1>
			            <p>PAGE NOT FOUND</p>
			            <h5>Something went wrong or that page doesn’t exist yet. <br/> <br/> 
			            <a href="index.php" class="btn btn-sm btn-primary">Return Home</a></h5>
			        </div>
                </div>
                   
            </div>
        </div>
        <!-- akhir:main -->