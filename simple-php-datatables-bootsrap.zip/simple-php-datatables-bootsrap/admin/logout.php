<?php
session_start();
session_destroy();
  echo "<SCRIPT type='text/javascript'>
        alert('Hati - Hati di jalan kk ^_^');
        window.location.replace('../index.php');
        </SCRIPT>";
?>
